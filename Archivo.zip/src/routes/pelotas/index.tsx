import { useEffect, useMemo, useState } from 'react';
import { getContent, setContent } from '../../lib/storage';
import { CMSContent } from '../../data/schema';
import { defaultCMSContent } from '../../data/seed';
import Field from '../../components/forms/Field';
import ConfigCard from '../../components/ui/ConfigCard';
import { ahorroMensualEuros, co2EvitadoKg } from '../../lib/calc';

const sections = [
  { id: 'funciona', label: 'Cómo funciona' },
  { id: 'calc', label: 'Calculadora' },
  { id: 'planes', label: 'Planes' },
  { id: 'faqs', label: 'FAQs' },
  { id: 'contacto', label: 'Contacto' },
];

const STORAGE_KEY = 'cms:rebote';

export default function PelotasRoute() {
  // Cargar/guardar contenido editable (CMS local)
  const [cms, setCms] = useState<CMSContent>(() => {
    const saved = getContent<CMSContent>(STORAGE_KEY);
    return saved ?? defaultCMSContent;
  });

  useEffect(() => {
    setContent(STORAGE_KEY, cms);
  }, [cms]);

  // Estado de calculadora
  const [pelotasMes, setPelotasMes] = useState<number>(300);
  const [precioTubo, setPrecioTubo] = useState<number>(6.0);
  const [ciclosRebote, setCiclosRebote] = useState<number>(3);

  const p = cms.rebote;

  const ahorro = useMemo(
    () => ahorroMensualEuros(pelotasMes, precioTubo, ciclosRebote, p.ajustes.factorAprovechamiento),
    [pelotasMes, precioTubo, ciclosRebote, p.ajustes.factorAprovechamiento]
  );

  const co2 = useMemo(
    () => co2EvitadoKg(pelotasMes, p.ajustes.co2KgPorPelotaEvitable, ciclosRebote),
    [pelotasMes, p.ajustes.co2KgPorPelotaEvitable, ciclosRebote]
  );

  useEffect(() => {
    // subnav activa al hacer scroll, igual que en /custom
    const observer = new IntersectionObserver(
      (entries) =>
        entries.forEach((entry) => entry.isIntersecting && setActive(entry.target.id)),
      { rootMargin: '-100px 0px -66% 0px' }
    );
    sections.forEach(({ id }) => {
      const el = document.getElementById(id);
      if (el) observer.observe(el);
    });
    return () => observer.disconnect();
  }, []);

  const [active, setActive] = useState('funciona');
  const scrollTo = (id: string) =>
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });

    return (
    <div className="theme-reciclaje">
      {/* Subnav estilo sitio */}
      <nav className="subnav">
        <div className="container">
          <div className="pills">
            {sections.map((s) => (
              <button
                key={s.id}
                className="pill"
                aria-current={active === s.id ? 'true' : undefined}
                onClick={() => scrollTo(s.id)}
              >
                {s.label}
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Hero consistente */}
      <section className="section">
        <div className="max-w">
          <div className="hero hero-split hero--bleed">
            <div className="hero-card">
              <span className="eyebrow">SOSTENIBILIDAD</span>
              <h1 className="h1">{p.hero.titulo}</h1>
              <p className="lead">{p.hero.subtitulo}</p>
              <div className="btn-row">
                <a className="btn primary" href="#/pelotas#calc">Abrir calculadora</a>
                <a className="btn btn-outline" href="#/pelotas#planes">Ver planes</a>
              </div>
            </div>
            <div className="hero-card hero-blob" aria-hidden="true" />
          </div>
        </div>
      </section>

      {/* Cómo funciona */}
      <section id="funciona" className="section">
        <div className="container">
          <h2 className="h2 text-center">{p.funciona.titulo}</h2>
          <p className="lead text-center reading">{p.funciona.descripcion}</p>

          <div className="grid cols-2 gap-16 mt-6">
            <div className="card">
              <ul className="list">
                {p.funciona.pasos.map((step, i) => (
                  <li key={i}>{step}</li>
                ))}
              </ul>
            </div>
            <div className="card">
              <h3 className="h3">{p.funciona.destacado.titulo}</h3>
              <p className="mt-1">{p.funciona.destacado.texto}</p>
            </div>
          </div>
        </div>
      </section>

      {/* Calculadora */}
      <section id="calc" className="section">
        <div className="container">
          <h2 className="h2 text-center">Calculadora</h2>
          <p className="lead text-center">Ajusta los parámetros para estimar tu ahorro y el impacto ambiental.</p>

          <div className="config-grid mt-6">
            <ConfigCard title="Parámetros">
              <Field label="Pelotas usadas al mes">
                <input
                  type="number"
                  min={0}
                  value={pelotasMes}
                  onChange={(e) => setPelotasMes(Number(e.target.value) || 0)}
                />
              </Field>

              <Field label="Precio por tubo (€)" hint={`Predeterminado: ${precioTubo.toFixed(2)} €`}>
                <input
                  type="number"
                  min={0}
                  step={0.1}
                  value={precioTubo}
                  onChange={(e) => setPrecioTubo(Number(e.target.value) || 0)}
                />
              </Field>

              <Field label="Ciclos de re-presurización (veces)">
                <input
                  type="number"
                  min={1}
                  step={1}
                  value={ciclosRebote}
                  onChange={(e) => setCiclosRebote(Number(e.target.value) || 1)}
                />
              </Field>
            </ConfigCard>

            <ConfigCard title="Resultado">
              <div className="result">
                <div className="badge-kpi">Ahorro mensual · € {ahorro.toFixed(0)}</div>
                <p className="muted mt-1">CO₂ evitado: {co2.toFixed(1)} kg</p>
              </div>

              <div className="stack-sm mt-4">
                {p.calculadora.beneficios.map((b, i) => (
                  <div key={i} className="card card-quiet">
                    <h4 className="h4">{b.titulo}</h4>
                    <p className="mt-1">{b.texto}</p>
                  </div>
                ))}
              </div>
            </ConfigCard>
          </div>
        </div>
      </section>

      {/* Planes */}
      <section id="planes" className="section">
        <div className="container">
          <h2 className="h2 text-center">Planes</h2>
          <p className="lead text-center">{p.planes.descripcion}</p>

          <div className="grid cols-3 gap-16 mt-6">
            {p.planes.items.map((plan) => (
              <ConfigCard
                key={plan.id}
                title={plan.nombre}
                price={plan.precio}
                period="/mes"
                features={plan.puntos}
                ctaLabel="Solicitar"
                ctaHref={`mailto:${cms.contacto.email}?subject=Interés%20en%20plan%20${encodeURIComponent(plan.nombre)}`}
              />
            ))}
          </div>
        </div>
      </section>

      {/* FAQs */}
      <section id="faqs" className="section">
        <div className="container">
          <h2 className="h2 text-center">FAQs</h2>
          <div className="stack-md mt-6">
            {p.faqs.map((f, i) => (
              <details key={i} className="card">
                <summary className="cursor-pointer h4">{f.q}</summary>
                <p className="mt-1">{f.a}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* Contacto */}
      <section id="contacto" className="section">
        <div className="container">
          <h2 className="h2 text-center">Empieza hoy</h2>
          <p className="lead text-center">{cms.contacto.copy}</p>
          <div className="text-center">
            <a href={`mailto:${cms.contacto.email}`} className="btn btn-primary">
              Contactar
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}