import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Check } from 'lucide-react';
import { getContent, setContent } from '../../lib/storage';

type HomeContent = {
  hero: { badge: string; title: string; lead: string };
  valueProps: { t: string; d: string }[];
  comparativa: { fila: string; custom: string; rebote: string }[];
  logos: { name: string }[];
  proceso: string[];
  kpis: { value: string; label: string }[];
};

const DEFAULT_HOME: HomeContent = {
  hero: {
    badge: 'Soluciones integrales',
    title: 'Pádel para empresas y clubs',
    lead:
      'Desde proyectos a medida (CUSTOM 360) hasta re-presurización y reciclaje de pelotas (REBOTE).',
  },
  valueProps: [
    { t: 'Ahorro y eficiencia', d: 'Optimizamos costes sin perder rendimiento.' },
    { t: 'Sostenibilidad', d: 'Reducimos residuos y emisiones con procesos responsables.' },
    { t: 'Calidad garantizada', d: 'Estándares medibles y control de calidad en cada fase.' },
  ],
  comparativa: [
    { fila: 'Enfoque', custom: 'Proyecto a medida', rebote: 'Optimización de consumibles' },
    { fila: 'Horizonte', custom: 'Medio/Largo plazo', rebote: 'Corto/Medio plazo' },
    { fila: 'Impacto', custom: 'Infraestructura/operación', rebote: 'Coste mensual / CO₂' },
  ],
  logos: [{ name: 'Club A' }, { name: 'Empresa B' }, { name: 'Partner C' }],
  proceso: ['Análisis', 'Propuesta', 'Ejecución', 'Medición'],
  kpis: [
    { value: '+30', label: 'Proyectos' },
    { value: '-25%', label: 'Coste en pelotas' },
    { value: '-1.2t', label: 'CO₂/año' },
  ],
};

export default function Home() {
  const content = getContent<HomeContent>('cms_home') ?? DEFAULT_HOME;

  useEffect(() => {
    window.scrollTo(0, 0);
    if (!getContent('cms_home')) setContent('cms_home', DEFAULT_HOME);
  }, []);

  return (
    <div>
      {/* Hero */}
      <section className="hero">
        <div className="container">
          <div className="hero-split">
            <div className="hero-content">
              <div className="eyebrow">{content.hero.badge}</div>
              <h1 className="h1">{content.hero.title}</h1>
              <p className="lead">{content.hero.lead}</p>
              <div className="grid cols-2 gap-16">
                <Link className="btn btn-primary" to="/custom">
                  Ver CUSTOM
                </Link>
                <Link className="btn" to="/pelotas">
                  Ver REBOTE
                </Link>
              </div>
            </div>
            <div className="illustration" aria-hidden="true" />
          </div>
        </div>
      </section>

      {/* Value props */}
      <section className="section">
        <div className="container">
          <h2 className="h2 text-center">Qué hacemos en 30 segundos</h2>
          <div className="grid cols-auto-fit">
            {content.valueProps.map((prop, i) => (
              <div key={i} className="card">
                <div>
                  <Check size={28} strokeWidth={3} />
                </div>
                <h3 className="h3">{prop.t}</h3>
                <p>{prop.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Comparativa */}
      <section className="section">
        <div className="container">
          <h2 className="h2 text-center">Comparativa rápida</h2>
          <table className="comparison-table">
            <thead>
              <tr>
                <th></th>
                <th>CUSTOM PADEL 360</th>
                <th>REBOTE</th>
              </tr>
            </thead>
            <tbody>
              {content.comparativa.map((row, i) => (
                <tr key={i}>
                  <th>{row.fila}</th>
                  <td>{row.custom}</td>
                  <td>{row.rebote}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="grid cols-2 gap-16">
            <Link className="btn btn-primary" to="/custom">
              Explorar CUSTOM
            </Link>
            <Link className="btn btn-primary" to="/pelotas">
              Explorar REBOTE
            </Link>
          </div>
        </div>
      </section>

      {/* Logos */}
      <section className="section">
        <div className="container">
          <h2 className="h2 text-center">Clientes y Colaboradores</h2>
          <div className="logos-grid">
            {content.logos.map((logo, i) => (
              <div key={i} className="logo-placeholder">
                {logo.name}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Proceso */}
      <section className="section">
        <div className="container">
          <h2 className="h2 text-center">Proceso en 4 pasos</h2>
          <div className="timeline">
            {content.proceso.map((step, i) => (
              <div key={i} className="timeline-step">
                <div className="timeline-number">{i + 1}</div>
                <div className="timeline-title">{step}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* KPIs */}
      <section className="section">
        <div className="container">
          <h2 className="h2 text-center">Nuestras Métricas</h2>
          <div className="grid cols-3">
            {content.kpis.map((kpi, i) => (
              <div key={i} className="kpi-card">
                <div className="kpi-value">{kpi.value}</div>
                <div className="kpi-label">{kpi.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA final */}
      <section id="empieza-hoy" className="cta-start">
        <div className="container">
          <div className="cta-card">
            <div className="cta-start__inner">
              <h2 className="cta-title">EMPIEZA HOY</h2>
              <p className="cta-lead">
                Cuéntanos tu proyecto o solicita una estimación. Te respondemos rápido con la mejor opción para tu club o empresa.
              </p>
              <div className="cta-actions">
                <a className="btn btn-lg primary" href="mailto:info@custompadel360.com">
                  Solicitar presupuesto
                </a>
                <Link className="btn btn-lg ghost" to="/pelotas#planes">
                  Ver planes
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}