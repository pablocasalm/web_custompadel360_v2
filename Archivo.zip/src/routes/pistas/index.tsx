import { useEffect, useMemo, useState } from 'react';
import { Hammer, Wrench, Shield } from 'lucide-react';
import { getContent, setContent } from '../../lib/storage';
import Field from '../../components/forms/Field';
import ConfigCard from '../../components/ui/ConfigCard';

// ------- Contenido por defecto mínimo (puedes sobreescribir desde Admin JSON) -------
const DEFAULT_CUSTOM = {
  oferta: {
    title: 'CUSTOM PADEL 360 — Pistas a medida',
    text: 'Diseño, fabricación e instalación de pistas de pádel profesionales. Proyecto llave en mano para clubes y promotores.',
  },
  servicios: [
    { title: 'Diseño y obra', description: 'Estudio técnico, obra civil y coordinación integral.' },
    { title: 'Instalación', description: 'Estructura, cerramientos, vidrio y césped profesional.' },
    { title: 'Garantía y soporte', description: 'Mantenimiento y SLA según contrato.' },
  ],
  proyectos: [
    { t: 'Club Norte', d: '4 pistas panorámicas con LED y césped pro.' },
    { t: 'Centro Deportivo', d: '2 pistas clásicas, cerramiento 12mm.' },
    { t: 'Resort Costa', d: '3 pistas mixtas con zona de espectadores.' },
  ],
};

type Coefs = {
  base: number;
  estructura: Record<'Panorámica' | 'Clásica', number>;
  vidrio: Record<'10' | '12', number>;
  cesped: Record<'Pro' | 'Alta', number>;
  iluminacion: Record<'LED' | 'Halógena', number>;
};

type Opciones = {
  estructura: 'Panorámica' | 'Clásica';
  vidrio: 10 | 12;
  cesped: 'Pro' | 'Alta';
  iluminacion: 'LED' | 'Halógena';
};

// Cálculo básico: suma de partidas según coeficientes del Admin
function calcularPrecio(op: Opciones, coefs: Coefs): number {
  const total =
    (coefs.base || 0) +
    (coefs.estructura?.[op.estructura] || 0) +
    (coefs.vidrio?.[String(op.vidrio) as '10' | '12'] || 0) +
    (coefs.cesped?.[op.cesped] || 0) +
    (coefs.iluminacion?.[op.iluminacion] || 0);
  return Math.max(0, Math.round(total));
}

// Crea un resumen legible para copiar/pegar
function resumen(op: Opciones, total: number): string {
  return [
    'Estimación Pista de Pádel',
    `Estructura: ${op.estructura} · Vidrio: ${op.vidrio}mm`,
    `Césped: ${op.cesped} · Iluminación: ${op.iluminacion}`,
    '',
    `TOTAL estimado: € ${total.toLocaleString('es-ES')}`,
  ].join('\n');
}

const sections = [
  { id: 'ofrecemos', label: 'Qué ofrecemos' },
  { id: 'servicios', label: 'Servicios' },
  { id: 'config', label: 'Configurador' },
  { id: 'proyectos', label: 'Proyectos' },
  { id: 'contacto', label: 'Contacto' },
];

export default function PistasRoute() {
  // Contenido CMS (si no existe, siembra default)
  const content = getContent<any>('cms_custom') ?? DEFAULT_CUSTOM;

  const [activeSection, setActiveSection] = useState('ofrecemos');

  // Coeficientes desde "cms" (admin) o defaults
  const cms = getContent<any>('cms') ?? {};
  const coefs: Coefs = cms?.custom?.config?.coeficientes ?? {
    base: 10000,
    estructura: { Panorámica: 3500, Clásica: 0 },
    vidrio: { '10': 0, '12': 1200 },
    cesped: { Pro: 800, Alta: 400 },
    iluminacion: { LED: 900, Halógena: 0 },
  };

  // Estado de opciones del configurador
  const [op, setOp] = useState<Opciones>({
    estructura: 'Panorámica',
    vidrio: 12,
    cesped: 'Pro',
    iluminacion: 'LED',
  });

  const precio = useMemo(() => calcularPrecio(op, coefs), [op, coefs]);

  const copiar = async () => {
    await navigator.clipboard.writeText(resumen(op, precio));
    alert('Estimación copiada al portapapeles');
  };

  useEffect(() => {
    window.scrollTo(0, 0);
    if (!getContent('cms_custom')) setContent('cms_custom', DEFAULT_CUSTOM);

    const observer = new IntersectionObserver(
      (entries) => entries.forEach((entry) => entry.isIntersecting && setActiveSection(entry.target.id)),
      { rootMargin: '-100px 0px -66% 0px' }
    );
    sections.forEach((s) => {
      const el = document.getElementById(s.id);
      if (el) observer.observe(el);
    });
    return () => observer.disconnect();
  }, []);

  const scrollToSection = (id: string) =>
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });

  return (
    <div className="theme-pistas">
      <nav className="subnav">
        <div className="container">
          <div className="pills">
            {sections.map((section) => (
              <button
                key={section.id}
                className="pill"
                aria-current={activeSection === section.id ? 'true' : undefined}
                onClick={() => scrollToSection(section.id)}
              >
                {section.label}
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="section">
        <div className="max-w">
          <div className="hero hero-split hero--bleed">
            <div className="hero-card">
              <span className="eyebrow">SOLUCIONES B2B</span>
              <h1 className="h1">CUSTOM PADEL 360 — Pistas a medida</h1>
              <p className="lead">{DEFAULT_CUSTOM.oferta.text}</p>
              <div className="btn-row">
                <a className="btn primary" href="#/custom#proyectos">Ver proyectos</a>
                <a className="btn btn-outline" href="#/custom#contacto">Solicitar presupuesto</a>
              </div>
            </div>
            <div className="hero-card hero-blob" aria-hidden="true" />
          </div>
        </div>
      </section>

      {/* Qué ofrecemos */}
      <section id="ofrecemos" className="section">
        <div className="container">
          <h2 className="h2 text-center">{content.oferta?.title ?? DEFAULT_CUSTOM.oferta.title}</h2>
          <p className="lead text-center reading">{content.oferta?.text ?? DEFAULT_CUSTOM.oferta.text}</p>
        </div>
      </section>

      {/* Servicios */}
      <section id="servicios" className="section">
        <div className="container">
          <h2 className="h2 text-center">Servicios</h2>
        <div className="grid cols-3 gap-16">
            {(content.servicios ?? DEFAULT_CUSTOM.servicios).map((servicio: any, i: number) => (
              <div key={i} className="card">
                <div>
                  {i === 0 && <Hammer size={24} />}
                  {i === 1 && <Wrench size={24} />}
                  {i === 2 && <Shield size={24} />}
                </div>
                <h3 className="h3">{servicio.title}</h3>
                <p>{servicio.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Configurador */}
      <section id="config" className="section">
        <div className="container">
          <h2 className="h2 text-center">Configura tu pista</h2>
          <div className="config-grid">
            <ConfigCard title="Opciones">
              <Field label="Estructura">
                <select
                  value={op.estructura}
                  onChange={(e) => setOp((s) => ({ ...s, estructura: e.target.value as Opciones['estructura'] }))}
                >
                  <option>Panorámica</option>
                  <option>Clásica</option>
                </select>
              </Field>
              <Field label="Vidrio (mm)">
                <select
                  value={op.vidrio}
                  onChange={(e) => setOp((s) => ({ ...s, vidrio: Number(e.target.value) as Opciones['vidrio'] }))}
                >
                  <option value={10}>10</option>
                  <option value={12}>12</option>
                </select>
              </Field>
              <Field label="Césped">
                <select
                  value={op.cesped}
                  onChange={(e) => setOp((s) => ({ ...s, cesped: e.target.value as Opciones['cesped'] }))}
                >
                  <option>Pro</option>
                  <option>Alta</option>
                </select>
              </Field>
              <Field label="Iluminación">
                <select
                  value={op.iluminacion}
                  onChange={(e) => setOp((s) => ({ ...s, iluminacion: e.target.value as Opciones['iluminacion'] }))}
                >
                  <option>LED</option>
                  <option>Halógena</option>
                </select>
              </Field>
            </ConfigCard>

            <ConfigCard title="Estimación">
              <div className="result">
                <div className="badge-kpi">Precio: {precio.toLocaleString('es-ES')} €</div>
              </div>
              <button className="btn btn-primary" onClick={copiar}>
                Copiar estimación
              </button>
            </ConfigCard>
          </div>
        </div>
      </section>

      {/* Proyectos */}
      <section id="proyectos" className="section">
        <div className="container">
          <h2 className="h2 text-center">Proyectos</h2>
          <div className="grid cols-3 gap-16">
            {(content.proyectos ?? DEFAULT_CUSTOM.proyectos).map((proyecto: any, i: number) => (
              <div key={i} className="card">
                <div className="illustration" aria-hidden="true" />
                <h3 className="h3">{proyecto.t}</h3>
                <p>{proyecto.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contacto */}
      <section id="contacto" className="section">
        <div className="container">
          <h2 className="h2 text-center">Solicita tu presupuesto</h2>
          <p className="lead text-center">Cuéntanos las necesidades de tu proyecto y te responderemos.</p>
          <div className="text-center">
            <a href="mailto:info@custompadel360.com" className="btn btn-primary">
              Contactar
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}